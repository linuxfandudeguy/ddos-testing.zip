const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

// Serve the HTML content directly
const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>John Doe's Blog - DDoS Testing</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 2.5em;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        .announcement {
            background: #ffe6e6;
            border: 1px solid #ff9999;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }
        .main-content {
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
        .blog-post {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #ddd;
        }
        .blog-post h2 {
            color: #333;
            font-size: 1.8em;
        }
        .blog-post p {
            color: #666;
            font-size: 1.1em;
        }
        footer {
            background: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>John Doe's Personal Blog</h1>
            <p>Exploring the World of Technology and More</p>
        </div>
    </header>

    <div class="container main-content">
        <div class="announcement">
            <h2>Notice</h2>
            <p>This website is used for DDoS testing purposes. The content here is fictional and intended for testing network resilience.</p>
        </div>

        <div class="blog-post">
            <h2>Welcome to My Blog</h2>
            <p>Hello! I'm John Doe, and this is my personal blog where I share my thoughts on technology, programming, and other topics that interest me. Stay tuned for more updates and insights!</p>
            <p>Feel free to browse around and enjoy the content. If you have any questions or suggestions, don't hesitate to reach out.</p>
        </div>

        <div class="blog-post">
            <h2>The Future of Artificial Intelligence</h2>
            <p>Artificial Intelligence (AI) is rapidly evolving and changing the way we interact with technology. From self-driving cars to intelligent virtual assistants, AI is set to revolutionize numerous industries. In this article, we'll explore the current trends in AI and what the future might hold.</p>
            <p>AI is becoming more integrated into our daily lives, offering enhanced convenience and capabilities. However, it also raises important questions about ethics and job displacement. Stay informed about these developments as we delve deeper into AI's potential impact.</p>
        </div>

        <div class="blog-post">
            <h2>Top Programming Languages to Learn in 2024</h2>
            <p>Choosing the right programming language can significantly impact your career. In 2024, several languages are gaining prominence due to their versatility and demand in the job market. We'll discuss the top programming languages you should consider learning this year.</p>
            <p>Languages like Python, JavaScript, and Go are making waves with their wide applications and strong community support. Whether you're a beginner or an experienced developer, staying updated with these languages will enhance your skills and career prospects.</p>
        </div>

        <div class="blog-post">
            <h2>The Rise of Remote Work: Pros and Cons</h2>
            <p>Remote work has become increasingly popular, offering flexibility and work-life balance. However, it also comes with its own set of challenges. In this article, we’ll examine the benefits and drawbacks of remote work and how to effectively manage a remote team.</p>
            <p>Remote work provides opportunities for a better work-life balance and reduces commute time. On the flip side, it can lead to isolation and difficulties in maintaining team cohesion. Learn how to navigate these challenges and make the most of remote work.</p>
        </div>

        <div class="blog-post">
            <h2>Exploring the World of Quantum Computing</h2>
            <p>Quantum computing is a cutting-edge field that promises to solve complex problems beyond the reach of classical computers. This article will introduce you to the basics of quantum computing and its potential applications in various fields.</p>
            <p>From cryptography to drug discovery, quantum computing has the potential to transform industries by providing unprecedented processing power. Discover the fundamentals of quantum mechanics and how quantum computers work in this comprehensive guide.</p>
        </div>

        <div class="blog-post">
            <h2>Cybersecurity Trends to Watch in 2024</h2>
            <p>As technology evolves, so do the threats in the cybersecurity landscape. In 2024, several key trends are shaping the future of cybersecurity. This article will highlight the latest developments and what organizations need to do to protect their digital assets.</p>
            <p>With the rise of sophisticated cyber attacks and increasing data privacy concerns, staying ahead of the curve is crucial. Learn about the emerging threats and strategies to enhance your cybersecurity posture in this in-depth analysis.</p>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 John Doe. All rights reserved.</p>
    </footer>
</body>
</html>
`;

// Serve the HTML content
app.get('/', (req, res) => {
    res.send(htmlContent);
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
